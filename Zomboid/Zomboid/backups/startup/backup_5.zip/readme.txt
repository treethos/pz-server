Backup time: 2025-07-02 at 12:18:01 UTC
ServerName: servertest
Current server version:41.78
Current world version:195
World version in this backup is:World isn't exist