Backup time: 2025-07-02 at 12:23:36 UTC
ServerName: My Zomboid Server
Current server version:41.78
Current world version:195
World version in this backup is:World isn't exist