Backup time: 2025-07-02 at 12:55:54 UTC
ServerName: server-sophie-1-14
Current server version:41.78
Current world version:195
World version in this backup is:World isn't exist